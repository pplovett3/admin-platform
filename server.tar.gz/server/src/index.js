"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('ok');
//# sourceMappingURL=index.js.map